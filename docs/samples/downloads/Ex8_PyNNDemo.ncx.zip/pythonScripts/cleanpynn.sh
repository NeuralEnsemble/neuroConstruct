sudo rm -rf /usr/local/lib/python2.7/dist-packages/PyNN*
sudo rm -rf /usr/local/lib/python2.7/dist-packages/pynn
sudo rm -rf /usr/local/lib/python2.7/dist-packages/pyNN/
