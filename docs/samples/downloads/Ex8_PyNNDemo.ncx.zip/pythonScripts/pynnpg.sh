set -e
./cleanpynn.sh
cd /home/padraig/PyNN_PG
git pull
sudo python setup.py install
cd -
cd /usr/local/lib/python2.7/dist-packages/pyNN/neuron/nmodl
sudo rm -rf x86_64
sudo /usr/local/nrn/x86_64/bin/nrnivmodl
cd -

python -c "import pyNN; print('PyNN version is: %s'%pyNN.__version__)"

