Some of the examples here have been moved to https://github.com/OpenSourceBrain/PyNNShowcase
