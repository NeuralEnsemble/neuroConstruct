set -e
./cleanpynn.sh
cd /home/padraig/pyNN_NE
git pull
sudo python setup.py install
cd -
cd /usr/local/lib/python2.7/dist-packages/pyNN/neuron/nmodl
sudo rm -rf x86_64
sudo /home/padraig/nrn74/x86_64/bin/nrnivmodl
cd -

python -c "import pyNN; print('PyNN version is: %s'%pyNN.__version__)"

