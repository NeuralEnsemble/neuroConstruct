export JNML_HOME=/home/padraig/neuroConstruct/jNeuroMLJar
/home/padraig/neuroConstruct/jNeuroMLJar/jnml /home/padraig/neuroConstruct/osb/showcase/neuroConstructShowcase/Ex8_PyNNDemo/pythonScripts/../generatedNeuroML2/LEMS_Ex8_PyNNDemo.xml -nogui
